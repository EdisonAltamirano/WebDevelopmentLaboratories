# Star Wars 06

## File

* `server6.js`

## Instructions

* Look at the file sent to you then explain to the person next to you what the `res.sendFile` line does. Then try creating a new HTML file and routing to that one instead.
