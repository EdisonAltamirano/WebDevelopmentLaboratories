# Star Wars 03 (Commented)

## File

* `server4.js`

## Instructions

* Examine the code flagged in the comments. Was your hypothesis from the previous activity correct?

