# Star Wars 03

## File

* `server3.js`

## Instructions

* Examine the code flagged in the comments. Explain to those around you what it does and how it works. Be sure to create test cases that confirm your hypothesis.
