$(document).ready(function() {

// Start your code from here



});
